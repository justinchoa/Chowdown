

for r in range(5):   

   for c in range(r):       

        print(' ', end='') #Print with no newline   

print('#')