function openForm(){
    document.getElementById("popupForm").style.display = "block"
}

function closeForm(){
    document.getElementById("popupForm").style.display = "none"
}